////
////  FlickrModel.swift
////  Virtual Tourist
////
////  Created by Benjamin Clark on 7/7/16.
////  Copyright © 2016 Benjamin Clark. All rights reserved.
////




import Foundation
import CoreData

class FlickrModel: NSObject {
    
    //Shared Session
    
    var session: NSURLSession
    
    override init(){
        session = NSURLSession.sharedSession()
        super.init()
        
    }
    
    //Shared Instance
    
    class func sharedInstance() -> FlickrModel {
        struct Singleton {
            static var sharedInstance = FlickrModel()
        }
        return Singleton.sharedInstance
    }

//GET

    func getPicturesFromPin(pin: Pin, pageNum: Int, completionHandler: (result:[[String:String]]?,error:NSError?) -> Void) {
        
        let methodArguments: [String: AnyObject] = [
        "method" : FlickrModel.Methods.photoSearchMethod, FlickrMethod.ParameterKeys.ApiKEy: FlickrMethod.Constants.FlickrApiKey,
        "safe_search" : Constants.SAFE_SEARCH,
        "content_type": Constants.CONTENT_TYPE,
        "extras" : Constants.EXTRAS,
        "format" : Constants.DATA_FORMAT,
        "nojsoncallback" : Constants.NO_JSON_CALLBACK,
        "per_page" : Constants.PHOTOS_PER_PAGE,
        "page" : pageNum,
        "lat" : pin.coordinate.latitude,
        "lon" : pin.coordinate.latitude,
        "bbox" : creatBondingBoxString(pin.coordinate.latitude, long: pin.coordinate.longitude)
        
        ]
        let session = NSURLSession.sharedSession()
        let urlString = Constants.FlickrBaseURLSecure
        let url = NSURL(string: urlString)!
        let request = NSURLRequest(URL: url)
        
        let task = session.dataTaskWithRequest(request) {(data,response,error) in
            
            guard (error == nil) else {
                print("there was an error in your search request \(response.statusCode)")
                return
                
            }
            
            guard let statusCode = (response as? NSHTTPURLResponse)?.statusCode where statusCode >= 200 && <=299 else {
                
                if let response = response as? NSHTTPURLResponse {
                    print("Your request returned an invalid response! StatusCode = \(response.statusCode)")
                } else if let response = response {
                    print("Your request returned an invalid response! Response = \(response)")
                } else {
                    print("Your request returned an invalid response")
                
                }
                completionHandler(result: nil, error: nil)
                return
            }
            
            guard let data = data else {
                print("No data returned")
                completionHandler(result: nil, error: nil)
                return
            }
            
            let parsedResult: AnyObject!
            do {
                parsedResult = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments)
            } catch {
                parsedResult = nil
                print("Could not parse data")
                return
            }
            
            print(parsedResult)
        }
    
        //Did we get an error from Flickr?
        
        guard let stat = parsedResult["stat"] as? String where stat == "ok" else {
            print("Flickr returned an error. Check \(parsedResult)")
            completionHandler(result: nil, error: nil)
            return
        }
        
        guard let resultsDictionary = parsedResult["photos"] as? NSDictionary else {
            print("Connot find 'photos' in \(parsedResult)")
            completionHandler(result: nil, error: nil)
            
        }
        
        guard let photoDictionary = resultsDictionary["photo"] as? [[String?:AnyObject]] else {
            print("cannot find 'photo' in \(resultsDictionary)")
            completionHandler(result: nil, error: nil)
            return
        }
        
        let totalReturnedImages = photosDictionary.count
        let numberOfImages = min(totalReturnedImages, Constants.NUM_PHOTOS)
        let imageIndexArray = self.generateRandomIndexes(numberOfImages)
        
        var returnArray = [[String : String]]()
        
        for index in imageIndexArray {
            let urlString = photosDictionary[index]["url_q"] as! String
            let dictionary = ["url_q": urlString]
            returnArray.append(disctionary)
        }
        
        completionHandler(result: returnArray, error: nil)
    
    }

    task.resume()

    }

func imgFromURL (imgUrlString: Sting, completionHandler: (imageData: NSData?, error: NSError?) -> Void) ->NSURLSessionDataTask{
    
}



//
//func getImageFromFlickr() {
//    
//    // get session, url. Create NSURL and request
//    let session = NSURLSession.sharedSession()
//    let urlStr = BASE_URL + apiCallStringFromDictionary(self.searchDictionary)
//    let url = NSURL(string: urlStr)!
//    let request = NSURLRequest(URL: url)
//    
//    // create a data task..use completion handler defined below...
//    let task = session.dataTaskWithRequest(request, completionHandler: dataTaskCompletionHandler)
//    
//    // resume (begin) data task
//    task.resume()
//}
//
//
//
///* function to convert a dictionary of Flickr key/value params into a search string suitable
//for use in a url */
//func apiCallStringFromDictionary(parameters: [String: AnyObject]) -> String {
//    
//    // create an array of stings
//    var urlVars = [String]()
//    
//    // iterate thru parameters
//    for (key, value) in parameters {
//        
//        // Make sure that it is a string value
//        let stringValue = "\(value)"
//        
//        // force to allowed character
//        let escapedValue = stringValue.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
//        
//        // Append it
//        urlVars += [key + "=" + "\(escapedValue!)"]
//    }
//    
////    // join result in urlVars array by compbining by "&", return
////    let retString = (!urlVars.isEmpty ? "?" : "") + join("&", urlVars)
////    return retString
////}
////
////// completion handler for dataTaskWithRequest
////func dataTaskCompletionHandler(data: NSData?, response: NSURLResponse?, downloadError: NSError?) {
////    
////    // preset foundImage/Title to default...
////    var foundImage = UIImage(named: "SearchAgain")
////    var foundImageTitle = "No Image Found..search again"
////    
////    if let error = downloadError {
////        println("Could not complete the request \(error)")
////    } else {
////        
////        // valid response, get JSON data
////        var parsingError: NSError? = nil
////        let parsedResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments, error: &parsingError) as! NSDictionary
////        
////        // begin parsing data
////        if let photosDict = parsedResult["photos"] as? [String: AnyObject] {
////            
////            // test for valid page
////            if let page = self.searchPage as Int? {
////                
////                // valid random page has already been selected..this pass selects random image
////                
////                // read in array of photo dictionaries
////                if let photosArray = photosDict["photo"] as? [[String: AnyObject]] {
////                    
////                    // test for 0 photos
////                    if photosArray.count > 0 {
////                        
////                        // get a random photo
////                        let randomIndex = Int(arc4random_uniform(UInt32(photosArray.count)))
////                        let randomPhoto = photosArray[randomIndex] as [String: AnyObject]
////                        let randomUrlStr = randomPhoto["url_m"] as? String
////                        let imageUrl = NSURL(string: randomUrlStr!)
////                        
////                        // get image title
////                        var title = ""
////                        if let imageTitle = randomPhoto["title"] as? String {
////                            
////                            foundImageTitle = imageTitle
////                        }
////                        
////                        // get image data object
////                        if let imageData = NSData(contentsOfURL: imageUrl!) {
////                            
////                            // good image, convert to UIImage object
////                            foundImage = UIImage(data: imageData)
////                        }
////                    }
////                }
////                
////                // set to nil in preparation for next search
////                self.searchPage = nil
////            }
////            else {
////                
////                // 1. get a random page
////                // 2. assign self.searchPage to this random page
////                // 3. add "page" key to search dictionary
////                // 4. call function getImageFromFlickr()
////                if let pages = photosDict["pages"] as? Int {
////                    
////                    self.searchPage = Int(arc4random_uniform(UInt32(pages))) + 1
////                    self.searchDictionary["page"] = self.searchPage
////                    getImageFromFlickr()
////                }
////            }
////        }
////}
