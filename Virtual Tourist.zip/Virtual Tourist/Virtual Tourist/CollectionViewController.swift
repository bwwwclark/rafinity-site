//
//  File.swift
//  Virtual Tourist
//
//  Created by Benjamin Clark on 7/7/16.
//  Copyright © 2016 Benjamin Clark. All rights reserved.
//

import Foundation
import UIKit
import MapKit



class CollectionViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var CollectionMapView: MKMapView!
    
    @IBOutlet weak var CollectionView: UICollectionView!
    
    
    override func viewDidLoad() {
        CollectionMapView.delegate = self
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
